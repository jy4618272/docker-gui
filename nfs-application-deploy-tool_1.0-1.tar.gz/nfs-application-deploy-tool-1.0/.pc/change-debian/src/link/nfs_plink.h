#ifndef _NFS_PLINK_H_
#define _NFS_PLINK_H_

#include "global/global.h"
#define  P_LINK UI_DIR_PATH"/nfs_plink.ui"
#define  P_LINK_WINDOW "exter_access"
void p_link_contains();

#endif