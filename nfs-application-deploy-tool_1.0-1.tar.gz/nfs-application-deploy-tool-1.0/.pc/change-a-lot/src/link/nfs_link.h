#ifndef _NFS_LINK_H_
#define _NFS_LINK_H_

#include "global/global.h"

#define  DOCKER_LINK_CONTAINS "src/ui/nfs_link.ui"
#define  DOCKER_LINK_WINDOW "container_inter"
void create_link_contains();

#endif