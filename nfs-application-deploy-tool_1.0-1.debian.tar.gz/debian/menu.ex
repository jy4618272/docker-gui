?package(nfs-application-deploy-tool):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="nfs-application-deploy-tool" command="/usr/bin/nfs-application-deploy-tool"
