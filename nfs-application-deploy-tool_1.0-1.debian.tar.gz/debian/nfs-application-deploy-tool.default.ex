# Defaults for nfs-application-deploy-tool initscript
# sourced by /etc/init.d/nfs-application-deploy-tool
# installed at /etc/default/nfs-application-deploy-tool by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
